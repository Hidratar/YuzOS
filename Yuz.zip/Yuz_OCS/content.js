chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.action !== 'setTitle') return;
  if (typeof message.title === 'string') {
    document.title = message.title;
  }
});