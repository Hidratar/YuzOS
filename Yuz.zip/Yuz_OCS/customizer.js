function getGreeting(name) {
  const hour = new Date().getHours();
  let timeOfDay;
  if (hour < 12) {
    timeOfDay = 'Bom dia';
  } else if (hour < 18) {
    timeOfDay = 'Boa tarde';
  } else {
    timeOfDay = 'Boa noite';
  }
  return `${timeOfDay}, ${name}`;
}

const DEFAULT_CONFIG = {
  greetingName: 'Usuário',
  theme: 'dark',
  customShortcuts: [
    {
      name: 'Google',
      url: 'https://google.com',
      faviconUrl: 'https://www.google.com/s2/favicons?sz=64&domain=google.com',
      icon: 'bi-google'
    }
  ],
  backgroundLightUrl: 'background_light.jpg',
  backgroundDarkUrl: 'background_dark.jpg'
};

function saveConfig(config) {
  localStorage.setItem('yuzOcsConfig', JSON.stringify(config));
  applyConfig(config);
}

function loadConfig() {
  const savedConfig = localStorage.getItem('yuzOcsConfig');
  if (!savedConfig) return { ...DEFAULT_CONFIG };
  try {
    const parsed = JSON.parse(savedConfig);
    return Object.assign({}, DEFAULT_CONFIG, parsed);
  } catch (e) {
    return { ...DEFAULT_CONFIG };
  }
}

function applyConfig(config) {
  document.getElementById('greeting').textContent = getGreeting(config.greetingName);
  document.getElementById('greeting-name').value = config.greetingName;
  document.getElementById('theme-select').value = config.theme;
  document.body.setAttribute('data-theme', config.theme);
  const overlay = document.getElementById('background-overlay');
  let bgUrl = config.theme === 'light' ? config.backgroundLightUrl : config.backgroundDarkUrl;
  if (bgUrl && !/^https?:|^data:/.test(bgUrl)) {
    try {
      bgUrl = chrome.runtime.getURL(bgUrl);
    } catch (e) {}
  }
  overlay.style.backgroundImage = `url('${bgUrl}')`;
  const newsCard = document.getElementById('news-card');
  if (newsCard) newsCard.style.display = 'block';
  renderCustomShortcuts(config.customShortcuts);
}

function renderCustomShortcuts(shortcuts) {
  const list = document.getElementById('custom-shortcuts-list');
  list.innerHTML = '';
  shortcuts.forEach((shortcut) => {
    const item = document.createElement('a');
    item.href = shortcut.url;
    item.target = '_blank';
    item.className = 'shortcut-item';
    if (shortcut.faviconUrl) {
      item.innerHTML = `<img src="${shortcut.faviconUrl}" alt="${shortcut.name}" /> <span>${shortcut.name}</span>`;
    } else {
      const iconClass = shortcut.icon || 'bi-link-45deg';
      item.innerHTML = `<i class="bi ${iconClass}"></i> ${shortcut.name}`;
    }
    list.appendChild(item);
  });
}

function getFaviconUrl(siteUrl) {
  try {
    const hostname = new URL(siteUrl).hostname;
    return `https://www.google.com/s2/favicons?sz=64&domain=${hostname}`;
  } catch (e) {
    return null;
  }
}

const availableIcons = [
  'bi-github',
  'bi-file-earmark',
  'bi-link-45deg',
  'bi-code-slash',
  'bi-envelope-fill',
  'bi-house',
  'bi-book',
  'bi-lock-fill',
  'bi-bug-fill',
  'bi-book-fill',
  'bi-terminal-fill',
  'bi-newspaper',
  'bi-shield-fill-exclamation',
  'bi-plus-lg',
  'bi-check-circle',
  'bi-star',
  'bi-calendar-event',
  'bi-gear-fill',
  'bi-music-note',
  'bi-camera',
  'bi-cloud',
  'bi-heart'
];

function showIconSelector(callback) {
  const modal = document.getElementById('icon-selector');
  const grid = document.getElementById('icon-grid');
  const closeBtn = document.getElementById('icon-selector-close');
  grid.innerHTML = '';
  availableIcons.forEach(icon => {
    const opt = document.createElement('div');
    opt.className = 'icon-option';
    opt.innerHTML = `<i class="bi ${icon}"></i>`;
    opt.addEventListener('click', () => {
      modal.classList.add('hidden');
      closeBtn.removeEventListener('click', hide);
      callback(icon);
    });
    grid.appendChild(opt);
  });
  const autoOpt = document.createElement('div');
  autoOpt.className = 'icon-option';
  autoOpt.textContent = 'Auto';
  autoOpt.addEventListener('click', () => {
    modal.classList.add('hidden');
    closeBtn.removeEventListener('click', hide);
    callback(null);
  });
  grid.prepend(autoOpt);
  function hide() {
    modal.classList.add('hidden');
    closeBtn.removeEventListener('click', hide);
  }
  closeBtn.addEventListener('click', hide);
  modal.classList.remove('hidden');
}

function getAllShortcuts() {
  const config = loadConfig();
  const fixed = Array.from(document.querySelectorAll('#fixed-shortcuts a')).map(anchor => {
    const name = anchor.textContent.trim();
    const url = anchor.href;
    const iconEl = anchor.querySelector('i');
    const iconClass = iconEl && iconEl.classList.length > 1 ? iconEl.classList[1] : 'bi-link-45deg';
    return { name, url, icon: iconClass, faviconUrl: null };
  });
  const custom = config.customShortcuts.map(sc => {
    return {
      name: sc.name,
      url: sc.url,
      icon: sc.icon || null,
      faviconUrl: sc.faviconUrl || null
    };
  });
  return fixed.concat(custom);
}

function askForName() {
  const config = loadConfig();
  if (!config.greetingName || config.greetingName === 'Usuário') {
    showModal('Qual é o seu nome?', (name) => {
      if (name) {
        config.greetingName = name;
        saveConfig(config);
      }
    }, 'Digite seu nome...');
  }
}

document.getElementById('unsplash-btn').addEventListener('click', () => {
  const config = loadConfig();
  const key = config.theme === 'light' ? 'backgroundLightUrl' : 'backgroundDarkUrl';
  config[key] = `https://source.unsplash.com/random/1920x1080/?minimal,abstract,technology&t=${Date.now()}`;
  saveConfig(config);
});

document.getElementById('upload-bg-btn').addEventListener('click', () => {
  document.getElementById('bg-file-input').click();
});

document.getElementById('bg-file-input').addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    const config = loadConfig();
    const key = config.theme === 'light' ? 'backgroundLightUrl' : 'backgroundDarkUrl';
    config[key] = e.target.result;
    saveConfig(config);
  };
  reader.readAsDataURL(file);
});

document.getElementById('add-shortcut-btn').addEventListener('click', () => {
  showModal('Nome do Atalho:', (name) => {
    if (!name) return;
    showModal('URL do Atalho:', (url) => {
      if (!url) return;
      showIconSelector((icon) => {
        const config = loadConfig();
        const newShortcut = { name, url };
        if (icon) {
          newShortcut.icon = icon;
          newShortcut.faviconUrl = null;
        } else {
          const fav = getFaviconUrl(url);
          newShortcut.faviconUrl = fav;
        }
        config.customShortcuts.push(newShortcut);
        saveConfig(config);
      });
    });
  }, 'Digite o nome do atalho...');
});

document.getElementById('greeting-name').addEventListener('change', (e) => {
  const config = loadConfig();
  config.greetingName = e.target.value;
  saveConfig(config);
});

document.getElementById('theme-select').addEventListener('change', (e) => {
  const config = loadConfig();
  config.theme = e.target.value;
  saveConfig(config);
});

window.loadConfig = loadConfig;
applyConfig(loadConfig());
askForName();
