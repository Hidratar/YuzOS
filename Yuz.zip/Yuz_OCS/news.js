async function fetchNewsData() {
  const newsList = document.getElementById('news-list');
  const rssUrl = 'https://thehackernews.com/feeds/posts/default';
  const apiUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}`;

  try {
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    if (data.status === 'ok' && data.items && data.items.length > 0) {
      for (let i = 0; i < Math.min(5, data.items.length); i++) {
        const item = data.items[i];
        const newsItem = document.createElement('div');
        newsItem.className = 'news-item';
        const date = new Date(item.pubDate).toLocaleDateString('pt-BR');
        newsItem.innerHTML = `
          <a href="${item.link}" target="_blank">${item.title}</a>
          <small>Publicado em: ${date}</small>
        `;
        newsList.appendChild(newsItem);
      }
    } else {
      newsList.innerHTML = '<div>Nenhuma notícia recente encontrada.</div>';
    }
  } catch (error) {
    newsList.innerHTML = `<div>Erro ao carregar notícias: ${error.message}</div>`;
  }
}

fetchNewsData();
