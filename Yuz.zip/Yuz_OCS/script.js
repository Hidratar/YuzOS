
function updateClock() {
  const now = new Date();
  const time = now.toLocaleTimeString('pt-BR', { hour12: false });
  const date = now.toLocaleDateString('pt-BR');
  const devSpirit = document.getElementById('dev-spirit');
  devSpirit.textContent = `${time} | ${date}`;
}
function setupSearch() {
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
searchButton.addEventListener('click', performSearch);
searchInput.addEventListener('keypress', (e) => {
if (e.key === 'Enter') {
performSearch();
}
});
}
function performSearch() {
const query = document.getElementById('search-input').value;
if (query) {
window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
}
}
function setupTitleEditor() {
document.addEventListener('dblclick', (e) => {
if (e.target.tagName === 'BODY' || e.target.tagName === 'HTML' || e.target.id === 'main-container') {
showModal('Novo Título da Aba:', (newTitle) => {
if (newTitle) {
document.title = newTitle;
}
});
}
});
}
function showModal(title, callback, placeholder) {
  const modalContainer = document.getElementById('modal-container');
  const modalTitle = document.getElementById('modal-title');
  const modalInput = document.getElementById('modal-input');
  const modalConfirm = document.getElementById('modal-confirm');
  const modalCancel = document.getElementById('modal-cancel');
  modalTitle.textContent = title;
  modalInput.value = '';
  modalInput.placeholder = placeholder || '';
  modalContainer.classList.remove('hidden');
  modalInput.focus();
  function cleanup() {
    modalContainer.classList.add('hidden');
    modalConfirm.removeEventListener('click', handleConfirm);
    modalCancel.removeEventListener('click', handleCancel);
    modalInput.removeEventListener('keypress', handleKeyPress);
  }
  function handleConfirm() {
    cleanup();
    callback(modalInput.value);
  }
  function handleCancel() {
    cleanup();
    callback(null);
  }
  function handleKeyPress(e) {
    if (e.key === 'Enter') {
      handleConfirm();
    }
  }
  modalConfirm.addEventListener('click', handleConfirm);
  modalCancel.addEventListener('click', handleCancel);
  modalInput.addEventListener('keypress', handleKeyPress);
}

function setupSettingsPanel() {
const settingsButton = document.getElementById('settings-button');
const settingsPanel = document.getElementById('settings-panel');
settingsButton.addEventListener('click', () => {
settingsPanel.classList.toggle('open');
});
}
function setupEmailShortcut() {
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key && e.key.toLowerCase() === 'm') {
      e.preventDefault();
      const emailLink = document.getElementById('email-shortcut');
      if (emailLink) {
        window.open(emailLink.href, '_blank');
      }
    }
  });
}

function setupTabRenameShortcut() {
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key && e.key.toLowerCase() === 'b') {
      e.preventDefault();
      showModal('Defina um novo título:', (newTitle) => {
        if (newTitle) {
          document.title = newTitle;
          try {
            chrome.runtime.sendMessage({ action: 'setTitle', title: newTitle });
          } catch (err) {
          }
        }
      }, 'Digite o novo título...');
    }
  });
}

function setupVsCodeShortcut() {
  const vsLink = document.getElementById('vscode-shortcut');
  if (!vsLink) return;
  vsLink.addEventListener('click', (e) => {
    e.preventDefault();
    const vscodeUrl = vsLink.href || 'vscode://';
    try {
      window.location.href = vscodeUrl;
      setTimeout(() => {
        window.open('https://vscode.dev/', '_blank');
      }, 1000);
    } catch (err) {
      window.open('https://vscode.dev/', '_blank');
    }
  });
}

function setupSidebar() {
  const toggleBtn = document.getElementById('sidebar-toggle');
  const sidebar = document.getElementById('sidebar');
  if (!toggleBtn || !sidebar) return;
  toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('open');
  });
  function loadMostVisited() {
    if (typeof chrome !== 'undefined' && chrome.topSites && chrome.topSites.get) {
      chrome.topSites.get((sites) => {
        const listContainer = document.getElementById('most-visited-list');
        if (!listContainer) return;
        listContainer.innerHTML = '';
        const maxItems = 8;
        sites.slice(0, maxItems).forEach(site => {
          const a = document.createElement('a');
          a.href = site.url;
          a.target = '_blank';
          let iconHtml = '';
          try {
            const hostname = new URL(site.url).hostname;
            const favUrl = `https://www.google.com/s2/favicons?sz=64&domain=${hostname}`;
            iconHtml = `<img src="${favUrl}" alt="${hostname}" width="16" height="16" />`;
          } catch (err) {
            iconHtml = '<i class="bi bi-globe"></i>';
          }
          const title = site.title || site.url;
          a.innerHTML = `${iconHtml} <span>${title}</span>`;
          listContainer.appendChild(a);
        });
      });
    }
  }
  function loadLastOpened() {
    if (typeof chrome !== 'undefined' && chrome.history && chrome.history.search) {
      chrome.history.search({ text: '', maxResults: 1 }, (results) => {
        const container = document.getElementById('last-opened-item');
        if (!container) return;
        container.innerHTML = '';
        if (results && results.length > 0) {
          const last = results[0];
          const a = document.createElement('a');
          a.href = last.url;
          a.target = '_blank';
          let iconHtml;
          try {
            const hostname = new URL(last.url).hostname;
            const favUrl = `https://www.google.com/s2/favicons?sz=64&domain=${hostname}`;
            iconHtml = `<img src="${favUrl}" alt="${hostname}" width="16" height="16" />`;
          } catch (err) {
            iconHtml = '<i class="bi bi-clock-history"></i>';
          }
          const title = last.title || last.url;
          a.innerHTML = `${iconHtml} <span>${title}</span>`;
          container.appendChild(a);
        } else {
          container.textContent = 'Nenhum histórico recente';
        }
      });
    }
  }
  loadMostVisited();
  loadLastOpened();
}
function init() {
window.showModal = showModal;
updateClock();
setInterval(updateClock, 1000);
setupSearch();
setupTitleEditor();
setupSettingsPanel();
setupEmailShortcut();
  setupVsCodeShortcut();
  setupSidebar();
  setupTabRenameShortcut();
document.getElementById('dev-spirit').classList.remove('hidden');
}
init();